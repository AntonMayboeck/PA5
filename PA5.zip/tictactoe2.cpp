#include "tictactoe2.h"
using namespace std;



/*int main()
{
	srand(time(NULL));
	system("COLOR 7C");
	toetactic a;
	system("PAUSE");
}*/